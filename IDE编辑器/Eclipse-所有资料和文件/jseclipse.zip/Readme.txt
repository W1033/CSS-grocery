----------------------------------------------------------------------------------------
JSEclipse
 - version 1.5.5 of 2007-03-30
 - http://labs.adobe.com/technologies/jseclipse/
� 2006 Adobe Systems Incorporated. All rights reserved.
----------------------------------------------------------------------------------------

The JSEclipse_1.5.5.zip package contains
----------------------------------------------

- features/ - this folder includes the JSEclipse features
- plugins/ - this folder includes the JSEclipse plugin
- documentation - this folder contains the JSEclipse user manual in two different formats: Windows Help File (CHM) and FlashHelp
- License/ - the file includes the JSEclipse license (please select the one in your language)
- site.xml - this file is the site descriptor. It is used by the Eclipse IDE to determine the JSEclipse package location.
- Install.txt - the file includes the JSEclipse installation notes
- Readme.txt - this file